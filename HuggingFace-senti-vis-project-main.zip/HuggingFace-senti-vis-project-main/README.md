1)For easy to use current directory given.
2)generated responses based on the input. 
3)Hugging face token is secret , instruction followed - Do not share your Access Tokens with anyone;
4)You can replace your CSV file instead of my csv file.
5)i mentioned for the chatbot only my chat responses , so you can change whatever you need to get response.
6)For chat response got the sentimental analysis.
7)for sentimental visualization done.
8)for sentimaental analysis image also attached for your reference.


Name : Vergeena Devi.C
Contact number : 8124691458
Location : Chennai
Gmail : sayfutureai@gmail.com
